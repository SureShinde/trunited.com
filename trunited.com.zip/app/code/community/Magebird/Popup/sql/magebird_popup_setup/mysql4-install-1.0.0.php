<?php
/**
 * Magebird.com
 *
 * @category   Magebird
 * @package    Magebird_Popup
 * @copyright  Copyright (c) 2016 Magebird (http://www.Magebird.com)
 * @license    http://www.magebird.com/licence
 * Any form of ditribution, sell, transfer forbidden see licence above
 * Code has been obfuscated to prevent licence violations  
 */
$_X=__FILE__;$_a='JF9YPV9fRklMRV9fOyRfYj0nSkY5WVBWOWZSa2xNUlY5Zk95UmZXVDBuU2toS2JGa3hXa2xaYldoUFltcEdNMUJUVWpCaFIyeDZUM2M5UFNjN0pGOUVQWE4wY25KbGRpZ25aV1J2WTJWa1h6UTJaWE5oWWljcE8yVjJZV3dvSkY5RUtDUmZXU2twT3c9PSc7JF9GPXN0cnJldignZWRvY2VkXzQ2ZXNhYicpO2V2YWwoJF9GKCRfYikpOw==';$_R=strrev('edoced_46esab');eval($_R($_a));