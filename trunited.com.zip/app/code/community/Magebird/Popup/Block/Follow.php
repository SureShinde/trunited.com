<?php
/**
 * Magebird.com
 *
 * @category   Magebird
 * @package    Magebird_Popup
 * @copyright  Copyright (c) 2016 Magebird (http://www.Magebird.com)
 * @license    http://www.magebird.com/licence
 * Any form of ditribution, sell, transfer forbidden see licence above
 * Code has been obfuscated to prevent licence violations  
 */
$_X=__FILE__;$_g='JF9YPV9fRklMRV9fOyRfcz0nSkY5WVBWOWZSa2xNUlY5Zk95UmZXVDBuV1RKNGFHTXpUV2RVVjBadVdsZEtjR050VW1aVlJ6bDNaRmhDWmxGdGVIWlpNblJtVW0wNWMySkhPVE5KUjFZMFpFZFdkVnBJVFdkVVYwWnVXbGRLY0dOdFVtWlZSemwzWkZoQ1psRnRlSFpaTW5SbVZqSnNhMW95VmpCWU1FWnBZek5TZVZsWFRqQmxNekE5Snpza1gwUTljM1J5Y21WMktDZGxaRzlqWldSZk5EWmxjMkZpSnlrN1pYWmhiQ2drWDBRb0pGOVpLU2s3JzskX1M9c3RycmV2KCdlZG9jZWRfNDZlc2FiJyk7ZXZhbCgkX1MoJF9zKSk7';$_G=strrev('edoced_46esab');eval($_G($_g));